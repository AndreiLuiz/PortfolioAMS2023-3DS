import IBMCoordinatorHome from '@/components/coordenador-IBM/IBMCoordinatorHome'

export default async function Dashboard() {
  return <IBMCoordinatorHome />
}
