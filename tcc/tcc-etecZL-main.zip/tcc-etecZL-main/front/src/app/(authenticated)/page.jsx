import StudentHome from '@/components/aluno/StudentHome'

export default async function Home() {
  return <StudentHome />
}
