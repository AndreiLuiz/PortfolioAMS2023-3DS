import ETECCoordinatorHome from '@/components/coordenador-ETEC/ETECCoordinatorHome'

export default async function Dashboard() {
  return <ETECCoordinatorHome />
}
