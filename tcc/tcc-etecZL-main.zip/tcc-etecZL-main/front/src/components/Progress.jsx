// 'use client'

// export default function Progress({ percentage }) {
//   return (
//     <div
//       style={{
//         background: `conic-gradient(#0F62FE ${
//           percentage * 3.6
//         }deg, #EDEDED 0deg)`,
//       }}
//       className="mt-14 self-center progress w-40 h-40 bg-red-500 rounded-[50%] flex flex-col items-center justify-center before:absolute before:h-[130px] before:w-[130px] before:rounded-[50%] before:bg-white"
//     >
//       <span className="relative text-3xl font-semibold">{percentage}%</span>
//       <span className="relative text-sm">12/20.7 horas</span>
//     </div>
//   )
// }
