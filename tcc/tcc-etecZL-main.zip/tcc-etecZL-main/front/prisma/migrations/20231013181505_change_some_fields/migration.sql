-- AlterTable
ALTER TABLE `usuario` MODIFY `codEscola` INTEGER NULL,
    MODIFY `codTurma` INTEGER NULL;
