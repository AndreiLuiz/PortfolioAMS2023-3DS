-- AlterTable
ALTER TABLE `atividade` MODIFY `anexos` VARCHAR(191) NULL;
